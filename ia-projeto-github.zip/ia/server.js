const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Serve os arquivos do diretório public.
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (_req, res) => {
  res.json({
    ok: true,
    message: "Servidor da sua IA está funcionando."
  });
});

// Envia a página inicial quando existir public/index.html.
app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"), (err) => {
    if (err) {
      res.status(404).send(
        "Página inicial não encontrada. Adicione o arquivo public/index.html."
      );
    }
  });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Servidor iniciado na porta ${PORT}`);
});
